require("dotenv").config();

module.exports = {
  env: {
    REST_API:process.env.REST_API
  }
};
